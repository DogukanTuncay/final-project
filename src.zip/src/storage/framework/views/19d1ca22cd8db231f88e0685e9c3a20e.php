<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>
    <h1>DAVAH APP e hoşgeldin</h1>
</body>
</html>

<?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>