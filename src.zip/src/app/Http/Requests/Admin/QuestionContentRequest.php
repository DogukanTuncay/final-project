<?php

namespace App\Http\Requests\Admin;

use App\Http\Requests\BaseRequest;

class QuestionContentRequest extends BaseRequest
{
    public function rules()
    {
        return [
            //
        ];
    }
}