<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\BaseRequest;

class CourseChapterRequest extends BaseRequest
{
    public function rules()
    {
        return [
            //
        ];
    }
}