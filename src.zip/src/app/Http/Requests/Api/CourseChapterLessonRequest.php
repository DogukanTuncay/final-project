<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\BaseRequest;

class CourseChapterLessonRequest extends BaseRequest
{
    public function rules()
    {
        return [
            //
        ];
    }
}