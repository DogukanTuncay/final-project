<?php

namespace App\Http\Requests\Api;

use App\Http\Requests\BaseRequest;

class CourseRequest extends BaseRequest
{
    public function rules()
    {
        return [
            //
        ];
    }
}