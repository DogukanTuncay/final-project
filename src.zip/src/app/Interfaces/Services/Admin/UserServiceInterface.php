<?php

namespace App\Interfaces\Services\Admin;


interface UserServiceInterface
{
    // Eğer ekstra metodlar eklemek istersen buraya yazabilirsin
}
