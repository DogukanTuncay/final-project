<?php

namespace App\Interfaces\Repositories\Admin;

use App\Interfaces\Repositories\BaseRepositoryInterface;
interface QuestionContentRepositoryInterface extends BaseRepositoryInterface
{
    
}