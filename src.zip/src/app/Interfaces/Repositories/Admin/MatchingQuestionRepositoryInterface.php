<?php

namespace App\Interfaces\Repositories\Admin;

use App\Interfaces\Repositories\BaseRepositoryInterface;
interface MatchingQuestionRepositoryInterface extends BaseRepositoryInterface
{
   
}